# ShopFlow Modern

**Industry:** E-commerce

## Description
Modern e-commerce template with dynamic product grids, sticky cart, and smooth animations

## Design Features
- **Header:** sticky-transparent
- **Menu:** mega-menu
- **Footer:** multi-column
- **Layout:** grid-masonry
- **Cards:** elevated-hover
- **Buttons:** rounded-bold
- **Background:** diagonal-lines
- **Icons:** heroicons-outline

## Color Palette
- **Primary:** #e63946
- **Secondary:** #457b9d
- **Accent:** #f1faee
- **Text:** #1d3557
- **Background:** #ffffff

## Typography
- **Headings:** Poppins
- **Body:** Inter
