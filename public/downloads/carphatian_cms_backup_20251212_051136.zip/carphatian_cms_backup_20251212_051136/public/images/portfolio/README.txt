Portfolio Screenshot Instructions
==================================

Add screenshots for each project with these filenames:
1. saas-marketplace.jpg - Screenshot of chat.carphatian.ro
2. demo-tools.jpg - Screenshot of social.carphatian.ro
3. pdf-generator.jpg - Screenshot of social.carphatian.ro (PDF tool)
4. antimony-coin.jpg - Screenshot of explorer.carphatian.ro
5. language-detection.jpg - Screenshot of antimony.carphatian.ro
6. carpathian-cms.jpg - Screenshot of cms.carphatian.ro

Recommended size: 1200x675px (16:9 aspect ratio)
Format: JPG or PNG
