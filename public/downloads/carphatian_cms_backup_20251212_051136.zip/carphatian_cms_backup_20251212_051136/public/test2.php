<?php error_log("TEST PHP WORKS"); echo "Hello World"; ?>
