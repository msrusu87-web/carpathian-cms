<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    protected $supportedLocales = ['en', 'ro', 'es', 'it', 'de', 'fr'];

    public function handle(Request $request, Closure $next): Response
    {
        $locale = $request->segment(1);
        
        if (in_array($locale, $this->supportedLocales)) {
            App::setLocale($locale);
            Session::put('locale', $locale);
        } elseif (Session::has('locale')) {
            $sessionLocale = Session::get('locale');
            if (in_array($sessionLocale, $this->supportedLocales)) {
                App::setLocale($sessionLocale);
            }
        } else {
            App::setLocale(config('app.locale', 'ro'));
        }
        
        return $next($request);
    }
}
