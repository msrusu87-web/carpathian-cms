<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PostResource\Pages;
use App\Models\Post;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Grid;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Mohamedsabil83\FilamentFormsTinyeditor\Components\TinyEditor;

class PostResource extends Resource
{
    protected static ?string $model = Post::class;
    
    protected static ?string $navigationIcon = 'heroicon-o-newspaper';

    protected static ?int $navigationSort = 1;
    
    public static function getNavigationGroup(): ?string
    {
        return __('Blog');
    }
    
    public static function getNavigationLabel(): string
    {
        return __('Articole');
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make(__('Post Content'))
                    ->schema([
                        Grid::make(2)->schema([
                            Forms\Components\TextInput::make('title')
                                                    ->label(__('Title'))
                                ->required()
                                ->live(onBlur: true)
                                ->afterStateUpdated(fn ($state, callable $set) => $set('slug', \Str::slug($state)))
                                ->maxLength(255),
                            
                            Forms\Components\TextInput::make('slug')
                                                    ->label(__('Slug'))
                                ->required()
                                ->unique(ignoreRecord: true)
                                ->maxLength(255),
                        ]),
                        
                        TinyEditor::make('content')
                                                ->label(__('Content'))
                            ->required()
                            ->columnSpanFull()
                            ->fileAttachmentsDisk('public')
                            ->fileAttachmentsDirectory('uploads')
                            ->profile('full'),
                        
                        Forms\Components\Textarea::make('excerpt')
                                                ->label(__('Excerpt'))
                            ->rows(3)
                            ->maxLength(500)
                            ->columnSpanFull()
                            ->helperText(__('Brief summary of the post (optional)')),
                    ]),

                Section::make(__('Media'))
                    ->schema([
                        Forms\Components\FileUpload::make('featured_image')
                                                ->label(__('Featured Image'))
                            ->image()
                            ->directory('posts')
                            ->maxSize(2048)
                            ->helperText(__('Recommended size: 1200x630px')),
                    ])
                    ->collapsible(),

                Section::make(__('Publishing'))
                    ->schema([
                        Grid::make(3)->schema([
                            Forms\Components\Select::make('status')
                                                    ->label(__('Status'))
                                ->options([
                                    'draft' => __('Draft'),
                                    'published' => __('Published'),
                                    'scheduled' => __('Scheduled'),
                                ])
                                ->default('draft')
                                ->required(),
                            
                            Forms\Components\Toggle::make('is_featured')
                                                   ->label(__('Featured'))
                                ->label(__('Featured Post'))
                                ->helperText(__('Show in featured sections')),
                            
                            Forms\Components\Toggle::make('allow_comments')
                                                   ->label(__('Allow Comments'))
                                ->label(__('Allow Comments'))
                                ->default(true),
                        ]),
                        
                        Forms\Components\DateTimePicker::make('published_at')
                                               ->label(__('Published At'))
                            ->label('Publish Date')
                            ->default(now())
                            ->helperText(__('Leave empty to publish immediately')),
                    ]),

                Section::make(__('Organization'))
                    ->schema([
                        Grid::make(2)->schema([
                            Forms\Components\Select::make('category_id')
                                                    ->label(__('Category'))
                                ->relationship('category', 'name')
                                ->searchable()
                                ->preload()
                                ->createOptionForm([
                                    Forms\Components\TextInput::make('name')->required(),
                                    Forms\Components\TextInput::make('slug')->required(),
                                    Forms\Components\Textarea::make('description'),
                                ]),
                            
                            Forms\Components\Select::make('user_id')
                                                    ->label(__('User'))
                                ->relationship('user', 'name')
                                ->default(auth()->id())
                                ->required()
                                ->label(__('Author')),
                        ]),
                        
                        Forms\Components\Select::make('tags')
                                                ->label(__('Tags'))
                            ->relationship('tags', 'name')
                            ->multiple()
                            ->searchable()
                            ->preload()
                            ->createOptionForm([
                                Forms\Components\TextInput::make('name')->required(),
                                Forms\Components\TextInput::make('slug')->required(),
                            ]),
                    ])
                    ->collapsible(),

                Section::make(__('SEO'))
                    ->schema([
                        Forms\Components\TextInput::make('meta_title')
                                                ->label(__('Meta Title'))
                            ->maxLength(60)
                            ->helperText('Recommended: 50-60 characters'),
                        
                        Forms\Components\Textarea::make('meta_description')
                                                ->label(__('Meta Description'))
                            ->rows(3)
                            ->maxLength(160)
                            ->helperText('Recommended: 150-160 characters'),
                        
                        Forms\Components\Textarea::make('meta_keywords')
                                                ->label(__('Meta Keywords'))
                            ->rows(2)
                            ->helperText('Comma-separated keywords'),
                    ])
                    ->collapsible()
                    ->collapsed(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('featured_image')
                                       ->label(__('Featured Image'))
                    ->label(__('Image'))
                    ->circular(),
                
                Tables\Columns\TextColumn::make('title')
                                        ->label(__('Title'))
                    ->searchable()
                    ->sortable()
                    ->limit(50)
                    ->weight('bold'),
                
                Tables\Columns\BadgeColumn::make('status')
                                        ->label(__('Status'))
                    ->colors([
                        'secondary' => 'draft',
                        'success' => 'published',
                        'warning' => 'scheduled',
                    ])
                    ->icons([
                        'heroicon-o-pencil' => 'draft',
                        'heroicon-o-check-circle' => 'published',
                        'heroicon-o-clock' => 'scheduled',
                    ]),
                
                Tables\Columns\TextColumn::make('category.name')
                                        ->label(__('Category'))
                    ->sortable()
                    ->searchable()
                    ->badge()
                    ->color('info'),
                
                Tables\Columns\TextColumn::make('user.name')
                                       ->label(__('Author'))
                    ->label(__('Author'))
                    ->sortable()
                    ->searchable(),
                
                Tables\Columns\IconColumn::make('is_featured')
                                       ->label(__('Featured'))
                    ->label(__('Featured'))
                    ->boolean()
                    ->trueIcon('heroicon-o-star')
                    ->falseIcon('heroicon-o-star')
                    ->trueColor('warning')
                    ->falseColor('gray'),
                
                Tables\Columns\TextColumn::make('views')
                                        ->label(__('Views'))
                    ->numeric()
                    ->sortable()
                    ->alignEnd(),
                
                Tables\Columns\TextColumn::make('published_at')
                                        ->label(__('Published At'))
                    ->dateTime('M d, Y')
                    ->sortable()
                    ->toggleable(),
                
                Tables\Columns\TextColumn::make('created_at')
                                        ->label(__('Created At'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                SelectFilter::make('status')
                    ->options([
                        'draft' => __('Draft'),
                        'published' => __('Published'),
                        'scheduled' => __('Scheduled'),
                    ]),
                
                SelectFilter::make('category')
                    ->relationship('category', 'name'),
                
                TernaryFilter::make('is_featured')
                    ->label(__('Featured Posts')),
                
                Tables\Filters\TrashedFilter::make(),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
                Tables\Actions\Action::make('view_post')
                    ->label(__('View on Site'))
                    ->icon('heroicon-o-eye')
                    ->url(fn (Post $record): string => url('/posts/' . $record->slug))
                    ->openUrlInNewTab(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    Tables\Actions\ForceDeleteBulkAction::make(),
                    Tables\Actions\RestoreBulkAction::make(),
                    
                    Tables\Actions\BulkAction::make('publish')
                        ->label(__('Publish Selected'))
                        ->icon('heroicon-o-check-circle')
                        ->requiresConfirmation()
                        ->action(fn ($records) => $records->each->update(['status' => 'published', 'published_at' => now()])),
                    
                    Tables\Actions\BulkAction::make('draft')
                        ->label(__('Move to Draft'))
                        ->icon('heroicon-o-pencil')
                        ->requiresConfirmation()
                        ->action(fn ($records) => $records->each->update(['status' => 'draft'])),
                    
                    Tables\Actions\BulkAction::make('feature')
                        ->label(__('Mark as Featured'))
                        ->icon('heroicon-o-star')
                        ->requiresConfirmation()
                        ->action(fn ($records) => $records->each->update(['is_featured' => true])),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPosts::route('/'),
            'create' => Pages\CreatePost::route('/create'),
            'edit' => Pages\EditPost::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ]);
    }

}
