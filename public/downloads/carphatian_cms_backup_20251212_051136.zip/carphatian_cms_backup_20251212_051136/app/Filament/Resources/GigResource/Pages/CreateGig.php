<?php

namespace App\Filament\Resources\GigResource\Pages;

use App\Filament\Resources\GigResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGig extends CreateRecord
{
    protected static string $resource = GigResource::class;
}
