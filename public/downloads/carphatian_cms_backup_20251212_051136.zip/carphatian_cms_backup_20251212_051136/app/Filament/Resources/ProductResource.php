<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Filament\Resources\ProductResource\RelationManagers;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ProductResource extends Resource

{
    public static function getNavigationGroup(): ?string
    {
        return __('Shop');
    }

    public static function getNavigationLabel(): string
    {
        return __('Products');
    }


    protected static ?string $navigationIcon = 'heroicon-o-shopping-bag';

    
    protected static ?int $navigationSort = 1;
    protected static ?string $model = Product::class;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('category_id')
                                        ->label(__('Category'))
                    ->relationship('category', 'name'),
                Forms\Components\TextInput::make('name')
                                        ->label(__('Name'))
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('slug')
                                        ->label(__('Slug'))
                    ->required()
                    ->maxLength(255),
                Forms\Components\Textarea::make('description')
                                        ->label(__('Description'))
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('content')
                                        ->label(__('Content'))
                    ->columnSpanFull(),
                Forms\Components\TextInput::make('sku')
                                       ->label(__('SKU'))
                    ->label('SKU')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('price')
                                        ->label(__('Price'))
                    ->required()
                    ->numeric()
                    ->prefix('$'),
                Forms\Components\TextInput::make('sale_price')
                                        ->label(__('Sale Price'))
                    ->numeric(),
                Forms\Components\TextInput::make('stock')
                                        ->label(__('Stock'))
                    ->required()
                    ->numeric()
                    ->default(0),
                Forms\Components\TextInput::make('images'),
                Forms\Components\TextInput::make('attributes'),
                Forms\Components\TextInput::make('meta'),
                Forms\Components\Toggle::make('is_featured')
                                        ->label(__('Featured'))
                    ->required(),
                Forms\Components\Toggle::make('is_active')
                                        ->label(__('Active'))
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('category.name')
                                        ->label(__('Category'))
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('name')
                                        ->label(__('Name'))
                    ->searchable(),
                Tables\Columns\TextColumn::make('slug')
                                        ->label(__('Slug'))
                    ->searchable(),
                Tables\Columns\TextColumn::make('sku')
                                       ->label(__('SKU'))
                    ->label('SKU')
                    ->searchable(),
                Tables\Columns\TextColumn::make('price')
                                        ->label(__('Price'))
                    ->money()
                    ->sortable(),
                Tables\Columns\TextColumn::make('sale_price')
                                        ->label(__('Sale Price'))
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('stock')
                                        ->label(__('Stock'))
                    ->numeric()
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_featured')
                                        ->label(__('Featured'))
                    ->boolean(),
                Tables\Columns\IconColumn::make('is_active')
                                        ->label(__('Active'))
                    ->boolean(),
                Tables\Columns\TextColumn::make('created_at')
                                        ->label(__('Created At'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                                        ->label(__('Updated At'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }


    public static function shouldRegisterNavigation(): bool
    {
        return \App\Models\Plugin::where('slug', 'ecommerce')->where('is_active', true)->exists();
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'view' => Pages\ViewProduct::route('/{record}'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
