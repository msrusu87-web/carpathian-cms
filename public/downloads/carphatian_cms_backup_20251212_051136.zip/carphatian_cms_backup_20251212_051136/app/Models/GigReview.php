<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GigReview extends Model
{
    //
}
