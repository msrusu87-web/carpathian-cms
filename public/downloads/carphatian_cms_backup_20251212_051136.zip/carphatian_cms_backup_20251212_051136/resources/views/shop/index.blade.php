<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ __('messages.shop') }} - {{ config('app.name') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="{ mobileMenuOpen: false }">
    @include('partials.navigation')

    <main class="container mx-auto px-4 py-8">
        <!-- Breadcrumb -->
        <nav class="text-sm mb-6">
            <ol class="flex items-center space-x-2 text-gray-600">
                <li><a href="/" class="hover:text-blue-600">Acasă</a></li>
                <li><i class="fas fa-chevron-right text-xs"></i></li>
                <li class="text-blue-600 font-medium">Shop</li>
            </ol>
        </nav>

        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Sidebar -->
            <aside class="lg:w-1/4">
                <!-- Mobile Toggle -->
                <button @click="mobileMenuOpen = !mobileMenuOpen" 
                        class="lg:hidden w-full bg-white px-4 py-3 rounded-lg shadow mb-4 flex items-center justify-between">
                    <span class="font-semibold"><i class="fas fa-filter mr-2"></i> Filtre & Categorii</span>
                    <i class="fas fa-chevron-down" :class="{ 'rotate-180': mobileMenuOpen }"></i>
                </button>

                <div :class="{ 'hidden': !mobileMenuOpen }" class="lg:block space-y-6">
                    <!-- Categories -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h3 class="font-bold text-lg mb-4 flex items-center">
                            <i class="fas fa-th-large mr-2 text-blue-600"></i>
                            Categorii
                        </h3>
                        <ul class="space-y-2">
                            <li>
                                <a href="{{ route('shop.index') }}" 
                                   class="block py-2 px-3 rounded {{ !request('category') ? 'bg-blue-50 text-blue-600 font-semibold' : 'hover:bg-gray-50' }}">
                                    <i class="fas fa-border-all mr-2"></i> Toate Serviciile
                                </a>
                            </li>
                            @foreach($categories->whereNull('parent_id') as $parentCategory)
                                <li class="border-t pt-2 mt-2">
                                    <a href="{{ route('shop.index', ['category' => $parentCategory->slug]) }}" 
                                       class="block py-2 px-3 rounded font-medium {{ request('category') == $parentCategory->slug ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50' }}">
                                        <i class="fas fa-folder mr-2"></i> 
                                        {{ $parentCategory->getTranslation('name', app()->getLocale()) }}
                                        <span class="text-xs text-gray-500">({{ $parentCategory->products_count }})</span>
                                    </a>
                                    
                                    <!-- Subcategories -->
                                    @if($parentCategory->children->count() > 0)
                                        <ul class="ml-6 mt-2 space-y-1">
                                            @foreach($parentCategory->children as $childCategory)
                                                <li>
                                                    <a href="{{ route('shop.index', ['category' => $childCategory->slug]) }}" 
                                                       class="block py-1 px-3 rounded text-sm {{ request('category') == $childCategory->slug ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' }}">
                                                        <i class="fas fa-angle-right mr-1"></i>
                                                        {{ $childCategory->getTranslation('name', app()->getLocale()) }}
                                                        <span class="text-xs text-gray-400">({{ $childCategory->products_count }})</span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    @endif
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <!-- Price Filter -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h3 class="font-bold text-lg mb-4 flex items-center">
                            <i class="fas fa-tags mr-2 text-green-600"></i>
                            Preț
                        </h3>
                        <form method="GET" action="{{ route('shop.index') }}" class="space-y-3">
                            <input type="hidden" name="category" value="{{ request('category') }}">
                            <div>
                                <label class="text-sm text-gray-600">De la (RON)</label>
                                <input type="number" name="min_price" value="{{ request('min_price') }}" 
                                       class="w-full border rounded px-3 py-2 mt-1">
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Până la (RON)</label>
                                <input type="number" name="max_price" value="{{ request('max_price') }}" 
                                       class="w-full border rounded px-3 py-2 mt-1">
                            </div>
                            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
                                <i class="fas fa-filter mr-2"></i> Aplică Filtru
                            </button>
                        </form>
                    </div>

                    <!-- Featured Badge Info -->
                    <div class="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg p-6 border border-yellow-200">
                        <div class="flex items-start">
                            <i class="fas fa-star text-yellow-500 text-2xl mr-3"></i>
                            <div>
                                <h4 class="font-semibold text-gray-800 mb-1">Servicii Recomandate</h4>
                                <p class="text-sm text-gray-600">Cele mai populare servicii pentru afacerea ta</p>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Products Grid -->
            <div class="flex-1">
                <!-- Header -->
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800">
                            @if(request('category'))
                                @php
                                    $currentCat = $categories->firstWhere('slug', request('category'));
                                @endphp
                                {{ $currentCat ? $currentCat->getTranslation('name', app()->getLocale()) : 'Shop' }}
                            @else
                                Servicii Web Design
                            @endif
                        </h1>
                        <p class="text-gray-600 mt-1">{{ $products->total() }} servicii disponibile</p>
                    </div>

                    <!-- Sort -->
                    <form method="GET" class="flex items-center gap-2">
                        <input type="hidden" name="category" value="{{ request('category') }}">
                        <label class="text-sm text-gray-600">Sortează:</label>
                        <select name="sort" onchange="this.form.submit()" 
                                class="border rounded px-3 py-2 text-sm">
                            <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Nume (A-Z)</option>
                            <option value="price" {{ request('sort') == 'price' ? 'selected' : '' }}>Preț (Crescător)</option>
                            <option value="newest" {{ request('sort') == 'newest' ? 'selected' : '' }}>Cele mai noi</option>
                        </select>
                    </form>
                </div>

                @if($products->count() > 0)
                    <!-- Products Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        @foreach($products as $product)
            @php
                $locale = app()->getLocale();
                $name = $product->getTranslation('name', $locale, false)
                    ?? $product->getTranslation('name', 'ro', false)
                    ?? ($product->name ?? 'Produs');
                $description = $product->getTranslation('description', $locale, false)
                    ?? $product->getTranslation('description', 'ro', false)
                    ?? ($product->description ?? '');
            @endphp
                            <div class="bg-white rounded-xl shadow hover:shadow-2xl transition-all duration-300 overflow-hidden group">
                                <!-- Image -->
                                <div class="relative overflow-hidden h-56">
                                    @php
                                        $productImages = $product->images ? json_decode($product->images, true) : [];
                                        $firstImage = !empty($productImages) ? $productImages[0] : null;
                                    @endphp
                                    @if($firstImage)
                                        <img src="{{ asset($firstImage) }}"
                                             alt="{{ $name }}"
                                             class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                                    @else
                                        <div class="w-full h-full bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center">
                                            <i class="fas fa-laptop-code text-white text-5xl opacity-50"></i>
                                        </div>
                                    @endif
                                    
                                    @if($product->is_featured)
                                        <span class="absolute top-3 right-3 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-full shadow">
                                            <i class="fas fa-star"></i> Recomandat
                                        </span>
                                    @endif

                                    @if($product->sale_price)
                                        <span class="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                                            -{{ round((($product->price - $product->sale_price) / $product->price) * 100) }}%
                                        </span>
                                    @endif
                                </div>
                                
                                <!-- Content -->
                                <div class="p-6">
                                    <!-- Category Badge -->
                                    @if($product->category)
                                        <span class="inline-block bg-blue-100 text-blue-700 text-xs px-3 py-1 rounded-full mb-3">
                                            <i class="fas fa-tag"></i> {{ $product->category->getTranslation('name', $locale, false) ?? $product->category->getTranslation('name', 'ro', false) ?? $product->category->name }}
                                        </span>
                                    @endif

                                    <h3 class="font-bold text-xl mb-3 text-gray-800 group-hover:text-blue-600 transition">
                                        {{ $name }}
                                    </h3>
                                    
                                    <p class="text-gray-600 text-sm mb-4 line-clamp-2">
                                        {{ Str::limit($description, 120) }}
                                    </p>
                                    
                                    <!-- Price -->
                                    <div class="flex justify-between items-center mb-4 pt-4 border-t">
                                        @if($product->sale_price)
                                            <div class="flex flex-col">
                                                <span class="text-gray-400 line-through text-sm">{{ number_format($product->price, 0, ',', '.') }} RON</span>
                                                <span class="text-3xl font-bold text-green-600">{{ number_format($product->sale_price, 0, ',', '.') }} <span class="text-lg">RON</span></span>
                                            </div>
                                        @else
                                            <span class="text-3xl font-bold text-blue-600">{{ number_format($product->price, 0, ',', '.') }} <span class="text-lg">RON</span></span>
                                        @endif
                                    </div>
                                    
                                    <a href="{{ route('shop.show', $product->slug) }}" 
                                       class="block bg-gradient-to-r from-blue-600 to-blue-700 text-white text-center px-6 py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition font-semibold shadow-md hover:shadow-lg">
                                        <i class="fas fa-info-circle mr-2"></i> Vezi Detalii
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    
                    <!-- Pagination -->
                    <div class="mt-10">{{ $products->links() }}</div>
                @else
                    <!-- Empty State -->
                    <div class="bg-white rounded-lg shadow text-center py-16 px-6">
                        <i class="fas fa-search text-gray-300 text-6xl mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Nu am găsit servicii</h3>
                        <p class="text-gray-600 mb-6">Încearcă să modifici filtrele sau caută în alte categorii</p>
                        <a href="{{ route('shop.index') }}" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-redo mr-2"></i> Resetează Filtrele
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </main>
    
    @php
        $footerWidget = \App\Models\Widget::where('type', 'footer')->where('status', 'active')->first();
    @endphp
    @if($footerWidget)
        @include('widgets.footer', ['widget' => $footerWidget])
    @endif

    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>
</body>
</html>
