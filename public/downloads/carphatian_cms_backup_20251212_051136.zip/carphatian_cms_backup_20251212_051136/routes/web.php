<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\SitemapController;

// Homepage
Route::get('/', [FrontendController::class, 'index'])->name('home');

// Blog Routes
Route::get('/blog', [FrontendController::class, 'blog'])->name('blog');
Route::get('/posts/{slug}', [FrontendController::class, 'post'])->name('post.show');
Route::get('/category/{slug}', [FrontendController::class, 'category'])->name('category');
Route::get('/tag/{slug}', [FrontendController::class, 'tag'])->name('tag');
Route::get('/search', [FrontendController::class, 'search'])->name('search');

// Contact Routes
Route::get('/contact', [FrontendController::class, 'contact'])->name('contact');
Route::post('/contact', [FrontendController::class, 'contactSubmit'])->name('contact.submit');

// Shop Routes
Route::get('/shop', [App\Http\Controllers\ShopController::class, 'index'])->name('shop.index');
Route::get('/shop/products', [App\Http\Controllers\ShopController::class, 'products'])->name('shop.products');
Route::get('/shop/products/{slug}', [App\Http\Controllers\ShopController::class, 'show'])->name('shop.show');
Route::get('/shop/categories', [App\Http\Controllers\ShopController::class, 'categories'])->name('shop.categories');
Route::get('/shop/category/{slug}', [App\Http\Controllers\ShopController::class, 'category'])->name('shop.category');

// Cart Routes
Route::get('/cart', [App\Http\Controllers\CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add/{id}', [App\Http\Controllers\CartController::class, 'add'])->name('cart.add');
Route::patch('/cart/update/{id}', [App\Http\Controllers\CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/remove/{id}', [App\Http\Controllers\CartController::class, 'remove'])->name('cart.remove');
Route::delete('/cart/clear', [App\Http\Controllers\CartController::class, 'clear'])->name('cart.clear');

// Checkout Routes
Route::get('/checkout', [App\Http\Controllers\CheckoutController::class, 'index'])->name('checkout.index');
Route::post('/checkout/process', [App\Http\Controllers\CheckoutController::class, 'process'])->name('checkout.process');
Route::get('/checkout/success', [App\Http\Controllers\CheckoutController::class, 'success'])->name('checkout.success');

// Sitemap & SEO Routes (MUST BE BEFORE DYNAMIC PAGES)
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap.xml');
Route::get('/generate-sitemap', [SitemapController::class, 'generate'])->name('sitemap.generate');
Route::get('/robots.txt', function() {
    $content = "User-agent: *\nAllow: /\nSitemap: " . url('/sitemap.xml');
    return response($content, 200)->header('Content-Type', 'text/plain');
})->name('robots.txt');

// Language Switcher - Supported locales
$supportedLocales = ['en', 'ro', 'es', 'it', 'de', 'fr'];

foreach ($supportedLocales as $loc) {
    Route::get("/{$loc}", function () use ($loc) {
        session(['locale' => $loc]);
        app()->setLocale($loc);
        return redirect('/');
    })->name("locale.{$loc}");
}

// Filament Admin Locale Switcher
Route::post('/admin/locale/switch', function() use ($supportedLocales) {
    $locale = request('locale', 'ro');
    if (in_array($locale, $supportedLocales)) {
        session(['locale' => $locale]);
        session(['filament_locale' => $locale]);
        app()->setLocale($locale);
        
        // Also set cookie for persistence
        cookie()->queue('locale', $locale, 60 * 24 * 365); // 1 year
    }
    return redirect()->back();
})->name('filament.admin.locale.switch');

// Dynamic Pages Route (MUST BE LAST - catch-all)
Route::get('/{slug}', [FrontendController::class, 'page'])->name('page.show');
