<?php

namespace Plugins\Freelancer\Models;

use Illuminate\Database\Eloquent\Model;

class FreelancerMessage extends Model
{
    //
}
