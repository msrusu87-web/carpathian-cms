<?php

namespace Plugins\Freelancer\Models;

use Illuminate\Database\Eloquent\Model;

class FreelancerOrder extends Model
{
    //
}
