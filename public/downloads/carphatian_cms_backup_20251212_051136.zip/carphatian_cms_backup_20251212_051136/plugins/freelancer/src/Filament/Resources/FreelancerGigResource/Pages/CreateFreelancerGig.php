<?php
namespace Plugins\Freelancer\Filament\Resources\FreelancerGigResource\Pages;
use Plugins\Freelancer\Filament\Resources\FreelancerGigResource;
use Filament\Resources\Pages\CreateRecord;
class CreateFreelancerGig extends CreateRecord {
    protected static string $resource = FreelancerGigResource::class;
}
