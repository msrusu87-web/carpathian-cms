<?php
return array (
  'hero_title' => 'Trasforma le tue idee in realtà digitale',
  'hero_subtitle' => 'Piattaforma CMS moderna con intelligenza artificiale integrata per il tuo business',
  'home' => 'Home',
  'about' => 'Chi Siamo',
  'services' => 'Servizi',
  'blog' => 'Blog',
  'shop' => 'Negozio',
  'contact' => 'Contatti',
  'read_more' => 'Leggi di Più',
  'learn_more' => 'Scopri di Più',
  'get_started' => 'Inizia Ora',
  'contact_us' => 'Contattaci',
  'view_all' => 'Vedi Tutto',
);
