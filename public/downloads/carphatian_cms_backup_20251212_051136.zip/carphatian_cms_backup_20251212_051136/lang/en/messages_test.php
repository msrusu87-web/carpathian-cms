<?php
return array (
  'hero_title' => 'Transform your ideas into digital reality',
  'hero_subtitle' => 'Modern CMS platform with integrated artificial intelligence for your business',
  'home' => 'Home',
  'about' => 'About',
  'services' => 'Services',
  'blog' => 'Blog',
  'shop' => 'Shop',
  'contact' => 'Contact',
  'read_more' => 'Read More',
  'learn_more' => 'Learn More',
  'get_started' => 'Get Started',
  'contact_us' => 'Contact Us',
  'view_all' => 'View All',
);
