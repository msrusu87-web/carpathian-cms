<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }} - Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gray-50">
    @include('partials.navigation')

    <!-- Dynamic Widgets -->
    @foreach($widgets as $widget)
        @if(view()->exists('widgets.' . $widget->type))
            @include('widgets.' . $widget->type, ['widget' => $widget])
        @else
            <!-- Fallback for unknown widget types -->
            <div class="py-8">
                <div class="container mx-auto px-4">
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <p class="text-yellow-800">
                            <strong>Widget:</strong> {{ $widget->title }} 
                            (Type: {{ $widget->type }} - Template not found)
                        </p>
                    </div>
                </div>
            </div>
        @endif
    @endforeach

</body>
</html>
