<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ __('messages.blog') }} - {{ config('app.name') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gray-50">
    @include('partials.navigation')

    <!-- Header -->
    <header class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12 md:py-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <h1 class="text-3xl md:text-5xl font-bold mb-4">{{ __('messages.our_blog') }}</h1>
            <p class="text-lg md:text-xl">{{ __('messages.blog_subtitle') }}</p>
        </div>
    </header>

    <!-- Blog Content -->
    <main class="max-w-7xl mx-auto px-4 py-12">
        @if($posts->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @foreach($posts as $post)
            <article class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                @if($post->featured_image)
                <img src="{{ asset('storage/' . $post->featured_image) }}" alt="{{ $post->getTranslation('title', app()->getLocale()) }}" class="w-full h-48 object-cover">
                @else
                <div class="bg-gradient-to-br from-blue-200 to-purple-200 h-48 flex items-center justify-center">
                    <svg class="w-16 h-16 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                @endif
                
                <div class="p-6">
                    @if($post->category)
                    <span class="inline-block bg-blue-100 text-blue-600 text-xs px-2 py-1 rounded mb-3">{{ $post->category->getTranslation('name', app()->getLocale()) }}</span>
                    @endif
                    
                    @if($post->is_featured)
                    <span class="inline-block bg-yellow-400 text-yellow-900 text-xs px-2 py-1 rounded mb-3 ml-2">{{ __('messages.featured') }}</span>
                    @endif
                    
                    <h2 class="text-2xl font-bold mb-2 hover:text-blue-600">
                        <a href="/posts/{{ $post->slug }}">{{ $post->getTranslation('title', app()->getLocale()) }}</a>
                    </h2>
                    
                    <p class="text-gray-600 mb-4">{{ Str::limit($post->getTranslation('excerpt', app()->getLocale()), 150) }}</p>
                    
                    <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <span>{{ $post->published_at->format('M d, Y') }}</span>
                        <span>{{ $post->views }} {{ __('messages.views') }}</span>
                    </div>
                    
                    <a href="/posts/{{ $post->slug }}" class="text-blue-600 hover:text-blue-700 font-semibold">{{ __('messages.read_more') }}</a>
                </div>
            </article>
            @endforeach
        </div>
        
        <!-- Pagination -->
        <div class="mt-12">
            {{ $posts->links() }}
        </div>
        @else
        <div class="text-center py-20">
            <svg class="w-24 h-24 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h2 class="text-2xl font-bold text-gray-600 mb-2">{{ __('messages.no_blog_posts_yet') }}</h2>
            <p class="text-gray-500 mb-6">{{ __('messages.start_creating_content') }}</p>
            <a href="/admin/posts" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">{{ __('messages.create_first_post') }}</a>
        </div>
        @endif
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 mt-12">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8 mb-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">{{ __('messages.web_agency') }}</h3>
                    <p class="text-gray-400">{{ __('messages.professional_web_development') }}</p>
                </div>
                <div>
                    <h4 class="font-bold mb-4">{{ __('messages.services') }}</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="/shop" class="hover:text-white">{{ __('messages.web_development') }}</a></li>
                        <li><a href="/shop" class="hover:text-white">{{ __('messages.mobile_apps') }}</a></li>
                        <li><a href="/shop" class="hover:text-white">{{ __('messages.ecommerce') }}</a></li>
                        <li><a href="/shop" class="hover:text-white">{{ __('messages.ui_ux_design') }}</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold mb-4">{{ __('messages.company') }}</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="/about-us" class="hover:text-white">{{ __('messages.about_us') }}</a></li>
                        <li><a href="/blog" class="hover:text-white">{{ __('messages.blog') }}</a></li>
                        <li><a href="/contact" class="hover:text-white">{{ __('messages.contact') }}</a></li>
                        <li><a href="/admin" class="hover:text-white">{{ __('messages.admin') }}</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold mb-4">{{ __('messages.contact') }}</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li>{{ __('messages.email') }}: hello@webagency.com</li>
                        <li>{{ __('messages.phone') }}: +1 (555) 123-4567</li>
                        <li>{{ __('messages.address') }}: 123 Tech Street</li>
                        <li>San Francisco, CA 94105</li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-800 pt-8 text-center text-gray-400">
                <p>&copy; {{ date('Y') }} {{ __('messages.web_agency') }}. {{ __('messages.all_rights_reserved') }}</p>
            </div>
        </div>
    </footer>

    <!-- Mobile Menu Toggle Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const openIcon = document.getElementById('menu-open-icon');
            const closeIcon = document.getElementById('menu-close-icon');

            if (menuButton) {
                menuButton.addEventListener('click', function() {
                    mobileMenu.classList.toggle('hidden');
                    openIcon.classList.toggle('hidden');
                    closeIcon.classList.toggle('hidden');
                });
            }
        });
    </script>
</body>
</html>
