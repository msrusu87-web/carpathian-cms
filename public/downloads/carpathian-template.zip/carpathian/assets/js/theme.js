// Carpathian Theme Scripts
console.log('Carpathian Theme Loaded');
