# Carpathian Theme

Modern and elegant theme for Carpathian CMS.

## Features
- Responsive design
- Dark mode support
- SEO optimized
- Multiple layouts
- Customizable colors
- Fast loading

## Installation
1. Upload the ZIP file through Admin > Templates
2. Click "Activate" to enable the theme
3. Configure theme settings

## Version
1.0.0

## Author
Carpathian CMS Team
