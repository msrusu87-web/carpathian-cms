# RetailPro Elite

**Industry:** E-commerce

## Description
Luxury e-commerce template with elegant dark theme, gold accents, and premium feel

## Design Features
- **Header:** centered-logo
- **Menu:** horizontal-elegant
- **Footer:** minimal-centered
- **Layout:** grid-uniform
- **Cards:** bordered-luxury
- **Buttons:** square-elegant
- **Background:** subtle-texture
- **Icons:** feather-icons

## Color Palette
- **Primary:** #d4af37
- **Secondary:** #2d2d2d
- **Accent:** #ffffff
- **Text:** #1a1a1a
- **Background:** #0a0a0a

## Typography
- **Headings:** Playfair Display
- **Body:** Montserrat
