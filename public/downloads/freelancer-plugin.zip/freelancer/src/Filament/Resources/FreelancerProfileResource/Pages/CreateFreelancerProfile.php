<?php
namespace Plugins\Freelancer\Filament\Resources\FreelancerProfileResource\Pages;
use Plugins\Freelancer\Filament\Resources\FreelancerProfileResource;
use Filament\Resources\Pages\CreateRecord;
class CreateFreelancerProfile extends CreateRecord {
    protected static string $resource = FreelancerProfileResource::class;
}
