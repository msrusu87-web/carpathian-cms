<?php
namespace Plugins\Freelancer\Filament\Resources\FreelancerOrderResource\Pages;
use Plugins\Freelancer\Filament\Resources\FreelancerOrderResource;
use Filament\Resources\Pages\CreateRecord;
class CreateFreelancerOrder extends CreateRecord {
    protected static string $resource = FreelancerOrderResource::class;
}
